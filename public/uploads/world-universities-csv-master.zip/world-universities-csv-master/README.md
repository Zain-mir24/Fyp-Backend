world-universities-csv
======================
This is a forked copy of two CSV files with universities in the US and around the world.

I have modified this to only include the University name and the .edu domain name that is associated with the university.  This is useful for identifying a college based on an email address.


